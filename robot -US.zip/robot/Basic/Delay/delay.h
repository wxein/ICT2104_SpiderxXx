#ifndef __DELAY_H
#define __DELAY_H

#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include "main.h"
void delay_us(u32 us) ;
void delay_ms(u16 ms) ;
void delay_s(u16 s) ;

#endif



