#ifndef __IIC_H
#define __IIC_H
#include <ti/devices/msp432p4xx/driverlib/driverlib.h>
#include "main.h"
void IIC_Init(void);

#endif

