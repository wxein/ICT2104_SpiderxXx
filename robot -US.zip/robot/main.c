/* Standard Includes */
#include <stdint.h>
#include <stdbool.h>
#include "app.h"
INT16U t = 0;
bool b_sta = OPEN;
INT8U auch_buff[200] = {0x00};
FP32 f_dis;
int main(void)
{
    App_Init();//Ӧ�ó����ʼ�� �ײ����Դ��ʼ��
    //Robot_Back(gast_ServoArray);
    Robot_Stand(gast_ServoArray);
    //Robot_Right(gast_ServoArray);
    while(1)
    {

        if(t++ / 500)
        {
            t = 0;
            b_sta =! b_sta;
            LED_Control(RED_LED, b_sta);
        }
        delay_ms(10);//������ʱ
        f_dis = Get_SR04Distance();
        if(Check_SR04Distance(f_dis))
        {
            //�ܿ��ϰ�
            //Robot_Stop(gast_ServoArray);
            LED_Control(GREEN_LED, OPEN);
        }

        LED_Control(GREEN_LED, CLOSE);

        //Hc05_Process(gauch_Uart0RecBuff);//��������
        sprintf((char*)auch_buff, "dis = %0.2f\r\n", f_dis);
        Uart0_SendString((char*)auch_buff, strlen((char*)auch_buff));
        //U0_Sprintf("Dis = %0.2f\r\n", Get_SR04Distance());
        //Robot_Stand(gast_ServoArray);
        //Robot_Back(gast_ServoArray);
        //Robot_Left(gast_ServoArray);
        //Robot_Stand(gast_ServoArray);
        Robot_Run(gast_ServoArray);
        //Robot_Right(gast_ServoArray);

        //Robot_Right(gast_ServoArray);
        //Robot_Stop(gast_ServoArray);

        //delay_ms(9000);
    }
}
